import java.util.Scanner;

// Main class
class StudentRegistrationSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        StudentManager studentManager = new StudentManager();

        while (true) {
            System.out.println("\nStudent Registration System");
            System.out.println("1. Register Student");
            System.out.println("2. View Registered Students");
            System.out.println("3. Delete Registered Student");
            System.out.println("4. Update Registered Student");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    // Register Student
                    System.out.print("Enter student name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter student age: ");
                    int age = scanner.nextInt();
                    System.out.print("Enter student major (for undergraduates, press Enter for others): ");
                    scanner.nextLine(); // Consume newline
                    String major = scanner.nextLine();

                    // Create Student object based on major
                    Student student;
                    if (major.isEmpty()) {
                        student = new Student(name, age);
                    } else {
                        student = new UndergraduateStudent(name, age, major);
                    }

                    studentManager.registerStudent(student);
                    break;

                case 2:
                    // View Registered Students
                    studentManager.viewRegisteredStudents();
                    break;

                case 3:
                    // Delete Registered Student
                    System.out.print("Enter the index of the student to delete: ");
                    int deleteIndex = scanner.nextInt();
                    studentManager.deleteRegisteredStudent(deleteIndex - 1);
                    break;

                case 4:
                    // Update Registered Student
                    System.out.print("Enter the index of the student to update: ");
                    int updateIndex = scanner.nextInt();
                    scanner.nextLine(); // Consume newline

                    System.out.print("Enter updated student name: ");
                    String updatedName = scanner.nextLine();
                    System.out.print("Enter updated student age: ");
                    int updatedAge = scanner.nextInt();
                    System.out.print("Enter updated student major (for undergraduates, press Enter for others): ");
                    scanner.nextLine(); // Consume newline
                    String updatedMajor = scanner.nextLine();

                    // Create Updated Student object based on major
                    Student updatedStudent;
                    if (updatedMajor.isEmpty()) {
                        updatedStudent = new Student(updatedName, updatedAge);
                    } else {
                        updatedStudent = new UndergraduateStudent(updatedName, updatedAge, updatedMajor);
                    }

                    studentManager.updateRegisteredStudent(updateIndex - 1, updatedStudent);
                    break;

                case 5:
                    // Exit
                    System.out.println("Exiting Student Registration System. Goodbye!");
                    System.exit(0);

                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 5.");
            }
        }
    }
}
