

// Base class for Student
class Student {
    protected String name;
    protected int age;

    // Parameterized constructor
    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Display method (to be overridden by subclasses)
    public void display() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
    }
}

// Subclass for UndergraduateStudent, inheriting from Student
class UndergraduateStudent extends Student {
    private String major;

    // Parameterized constructor
    public UndergraduateStudent(String name, int age, String major) {
        super(name, age);
        this.major = major;
    }

    // Display method overriding the base class method
    @Override
    public void display() {
        super.display();
        System.out.println("Major: " + major);
    }
}

// Class to manage student operations
class StudentManager {
    private static final int MAX_STUDENTS = 100;
    private Student[] students;
    private int studentCount;

    // Constructor
    public StudentManager() {
        students = new Student[MAX_STUDENTS];
        studentCount = 0;
    }

    // Method to register a new student
    public void registerStudent(Student student) {
        if (studentCount < MAX_STUDENTS) {
            students[studentCount++] = student;
            System.out.println("Student registered successfully.");
        } else {
            System.out.println("Cannot register more students. Maximum limit reached.");
        }
    }

    // Method to view registered students
    public void viewRegisteredStudents() {
        System.out.println("Registered Students:");
        for (int i = 0; i < studentCount; i++) {
            System.out.println("Student " + (i + 1) + ":");
            students[i].display();
            System.out.println("------------------------");
        }
    }

    // Method to delete a registered student
    public void deleteRegisteredStudent(int index) {
        if (index >= 0 && index < studentCount) {
            for (int i = index; i < studentCount - 1; i++) {
                students[i] = students[i + 1];
            }
            studentCount--;
            System.out.println("Student deleted successfully.");
        } else {
            System.out.println("Invalid index. No student deleted.");
        }
    }

    // Method to update a registered student
    public void updateRegisteredStudent(int index, Student newStudent) {
        if (index >= 0 && index < studentCount) {
            students[index] = newStudent;
            System.out.println("Student updated successfully.");
        } else {
            System.out.println("Invalid index. No student updated.");
        }
    }
}


